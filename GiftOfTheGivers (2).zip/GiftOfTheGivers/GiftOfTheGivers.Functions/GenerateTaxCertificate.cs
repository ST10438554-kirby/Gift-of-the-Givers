﻿using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using System.Net;
using System.Text.Json;

namespace GiftOfTheGivers.Functions;

public class GenerateTaxCertificate
{
    [Function("GenerateTaxCertificate")]
    public async Task<HttpResponseData> Run(
        [HttpTrigger(AuthorizationLevel.Anonymous,"get", "post")]
        HttpRequestData req)
    {
        var requestBody = await new StreamReader(req.Body).ReadToEndAsync();

        var donation = JsonSerializer.Deserialize<DonationRequest>(
            requestBody,
            new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            });

        if (donation == null)
        {
            var badResponse = req.CreateResponse(HttpStatusCode.BadRequest);
            await badResponse.WriteStringAsync("Invalid donation information.");
            return badResponse;
        }

        string referenceNumber =
            $"GOTG-{DateTime.Now:yyyyMMddHHmmss}";

        var certificate = new
        {
            CertificateType = "Prototype Tax Certificate",
            DonorName = donation.DonorName,
            Amount = donation.Amount,
            Currency = donation.Currency,
            DonationDate = DateTime.Now,
            ReferenceNumber = referenceNumber,
            Message = "This is a prototype tax certificate and is not an official tax document."
        };

        var response = req.CreateResponse(HttpStatusCode.OK);

        await response.WriteAsJsonAsync(certificate);

        return response;
    }
}

public class DonationRequest
{
    public string DonorName { get; set; } = "";
    public decimal Amount { get; set; }
    public string Currency { get; set; } = "";
}