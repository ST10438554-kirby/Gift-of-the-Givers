﻿using System;

namespace GiftOfTheGivers.Helpers
{
    public static class DonationHelper
    {
        public static decimal CalculateDonationTotal(decimal amount)
        {
            return amount;
        }

        public static string GenerateCertificateNumber()
        {
            return $"GOTG-{DateTime.Now:yyyyMMddHHmmss}";
        }

        public static string FormatDonationAmount(
            decimal amount,
            string currency)
        {
            return $"{currency} {amount:N2}";
        }
    }
}