﻿using GiftOfTheGivers.Models;
using Microsoft.AspNetCore.Mvc;

namespace GiftOfTheGivers.Controllers
{
    public class DonationController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Submit(Donation donation)
        {
            if (!ModelState.IsValid)
            {
                return View("Index", donation);
            }

            donation.DonationDate = DateTime.Now;

            donation.Reference =
                "GOTG-" + Random.Shared.Next(10000, 99999);

            return View("Confirmation", donation);
        }

        public IActionResult TaxCertificate(
            string donorName,
            decimal amount,
            string currency,
            string reference)
        {
            ViewBag.DonorName = donorName;
            ViewBag.Amount = amount;
            ViewBag.Currency = currency;
            ViewBag.Reference = reference;
            ViewBag.Date = DateTime.Now;

            return View();
        }
    }
}