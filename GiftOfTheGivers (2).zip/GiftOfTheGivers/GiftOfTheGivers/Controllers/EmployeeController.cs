﻿using GiftOfTheGivers.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GiftOfTheGivers.Controllers
{
    [Authorize(Roles = "Employee")]
    public class EmployeeController : Controller
    {
        public IActionResult Dashboard()
        {
            return View();
        }

        public IActionResult Volunteers()
        {
            var volunteers = new List<Volunteer>
            {
                new Volunteer
                {
                    FullName = "Ayesha Daniels",
                    Email = "ayesha@example.com",
                    Phone = "0712345678",
                    Skills = "First Aid",
                    Availability = "Weekends",
                    Location = "Cape Town"
                },

                new Volunteer
                {
                    FullName = "Mohammed Adams",
                    Email = "mohammed@example.com",
                    Phone = "0723456789",
                    Skills = "Logistics",
                    Availability = "Weekdays",
                    Location = "Bellville"
                }
            };

            return View(volunteers);
        }

        public IActionResult PostUpdate()
        {
            return View();
        }

        [HttpPost]
        public IActionResult PostUpdate(ProjectUpdate update)
        {
            if (!ModelState.IsValid)
            {
                return View(update);
            }

            ViewBag.Message = "Project update posted successfully.";

            return View();
        }
    }
}