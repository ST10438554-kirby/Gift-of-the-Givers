﻿using GiftOfTheGivers.Models;
using Microsoft.AspNetCore.Mvc;

namespace GiftOfTheGivers.Controllers
{
    public class VolunteerController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Register(Volunteer volunteer)
        {
            if (!ModelState.IsValid)
            {
                return View("Index", volunteer);
            }

            return View("Confirmation", volunteer);
        }
    }
}