﻿using System.ComponentModel.DataAnnotations;

namespace GiftOfTheGivers.Models
{
    public class Donation
    {
        public int DonationId { get; set; }

        [Required]
        public string DonorName { get; set; } = "";

        [Required]
        [EmailAddress]
        public string Email { get; set; } = "";

        [Required]
        [Range(1, 10000000)]
        public decimal Amount { get; set; }

        [Required]
        public string Currency { get; set; } = "ZAR";

        [Required]
        public string DonationType { get; set; } = "One-time";

        public DateTime DonationDate { get; set; } = DateTime.Now;

        public string Reference { get; set; } = "";
    }
}