﻿using System.ComponentModel.DataAnnotations;

namespace GiftOfTheGivers.Models
{
    public class ProjectUpdate
    {
        public int ProjectUpdateId { get; set; }

        [Required]
        public string ProjectName { get; set; } = "";

        [Required]
        public string UpdateText { get; set; } = "";

        public DateTime DatePosted { get; set; } = DateTime.Now;
    }
}