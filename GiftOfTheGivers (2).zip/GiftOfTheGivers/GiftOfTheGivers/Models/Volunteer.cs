﻿using System.ComponentModel.DataAnnotations;

namespace GiftOfTheGivers.Models
{
    public class Volunteer
    {
        public int VolunteerId { get; set; }

        [Required]
        public string FullName { get; set; } = "";

        [Required]
        public string FullSurname { get; set; } = "";

        [Required]
        [EmailAddress]
        public string Email { get; set; } = "";

        [Required]
        public string Phone { get; set; } = "";

        [Required]
        public string Skills { get; set; } = "";

        [Required]
        public string Availability { get; set; } = "";

        [Required]
        public string Location { get; set; } = "";
    }
}