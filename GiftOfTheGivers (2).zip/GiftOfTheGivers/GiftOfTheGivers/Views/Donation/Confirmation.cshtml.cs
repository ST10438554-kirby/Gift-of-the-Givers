using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GiftOfTheGivers.Views.Donation
{
    public class ConfirmationModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
