using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GiftOfTheGivers.Views.Donation
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
