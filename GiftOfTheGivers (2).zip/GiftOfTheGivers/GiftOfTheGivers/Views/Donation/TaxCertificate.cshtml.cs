using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GiftOfTheGivers.Views.Donation
{
    public class TaxCertificateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
