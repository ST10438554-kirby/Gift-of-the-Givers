using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GiftOfTheGivers.Views.Employee
{
    public class DashboardModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
