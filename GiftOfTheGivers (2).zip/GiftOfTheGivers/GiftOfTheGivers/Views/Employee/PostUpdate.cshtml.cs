using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GiftOfTheGivers.Views.Employee
{
    public class PostUpdateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
