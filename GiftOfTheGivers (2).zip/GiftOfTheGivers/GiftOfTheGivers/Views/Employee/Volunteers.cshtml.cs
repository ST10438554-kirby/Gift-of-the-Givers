using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GiftOfTheGivers.Views.Employee
{
    public class VolunteersModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
