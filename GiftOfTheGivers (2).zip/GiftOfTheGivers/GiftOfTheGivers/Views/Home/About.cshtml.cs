using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GiftOfTheGivers.Views.Home
{
    public class AboutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
