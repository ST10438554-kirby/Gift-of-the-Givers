using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GiftOfTheGivers.Views.Volunteer
{
    public class ConfirmationModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
