using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GiftOfTheGivers.Views.Volunteer
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
